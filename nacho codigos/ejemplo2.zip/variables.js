const usuario = document.getElementById('usuario');
const pass = document.getElementById('pass');

const usuario1 = document.getElementById('usuario1');
const pass1 = document.getElementById('pass1');
